CREATE TABLE users07 (
  user_id SERIAL,
  username VARCHAR(255),
  password VARCHAR(255),
  PRIMARY KEY (user_id)
);